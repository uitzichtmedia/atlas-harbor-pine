# LESSONS — mistakes the operator must never repeat

> **Instructions (delete when done).** Turn every failure into a rule; planner and executor read this file every run. Write a
> lesson after every FAILED or wrongly-DONE ledger item and after every owner correction: what happened (one line) → the rule
> (one imperative line) → how it is enforced. Prefer enforcement in code (a gate, a check) over a sentence in a prompt, and say
> which it is. Max 40 active lessons; when a lesson is enforced in code and has not recurred for 60 days, archive it.
> Size budget: 900 words.

## Template

### L-<NN> · <YYYY-MM-DD> · <short title>
- **What happened:** <one line, with ledger ID>
- **Rule:** <one imperative line>
- **Enforced by:** code: <file / gate> | prompt only

## Example — Harbor & Pine Candles

### L-01 · 2026-11-04 · "Done" without a live change
- **What happened:** T-0012 was marked DONE; the meta description was saved as a draft and never published.
- **Rule:** Verify against the live page, never against the executor's own report.
- **Enforced by:** code: the ledger refuses DONE without `external_result`; the live check re-reads the URL next run.

### L-02 · 2026-11-05 · Stale evidence caused a bad sync
- **What happened:** T-0019 used a supplier stock file that was 5 days old and set 4 products to 0 stock.
- **Rule:** Check evidence freshness before acting; never act on evidence older than 24 hours.
- **Enforced by:** code: collectors write `collected_at`; the executor preflight fails on stale files.

### L-03 · 2026-11-06 · One blocked task froze the queue
- **What happened:** T-0021 waited for an owner login and the executor retried it all day.
- **Rule:** Mark BLOCKED with the exact owner action, then take the next READY item.
- **Enforced by:** code: ledger `next` skips BLOCKED items; prompt: "never retry a BLOCKED item".
