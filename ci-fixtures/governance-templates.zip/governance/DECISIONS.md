# DECISIONS — the archive of what was decided, when and why

> **Instructions (delete when done).** Append-only. Every owner decision — and every operator decision with business impact —
> gets one entry. Never edit or delete an old entry; supersede it with a new one ("Supersedes D-007"). IDs are sequential
> (D-001, D-002 …), one decision per entry, under 80 words. Status is ACTIVE, SUPERSEDED or EXPIRED. This file grows, so the
> operator does NOT read it every run — it reads CURRENT.md. Past ~300 entries, move old SUPERSEDED/EXPIRED entries to an
> archive file per year.

## Template

### D-<NNN> · <YYYY-MM-DD> · <short title>
- **Decided by:** owner | operator (within AUTHORITY)
- **Decision:** <one or two sentences>
- **Why:** <evidence or reason>
- **Applies until:** <date | until superseded>
- **Status:** ACTIVE
- **Supersedes:** <D-NNN or –>

## Example — Harbor & Pine Candles

### D-001 · 2026-11-01 · Atlas may edit product content
- **Decided by:** owner
- **Decision:** Atlas may rewrite titles, meta descriptions and intros of up to 5 products per day, with snapshot and live verification.
- **Why:** 30 high-impression product pages have CTR below 2% (Search Console, Oct 2026).
- **Applies until:** until superseded
- **Status:** ACTIVE
- **Supersedes:** –

### D-002 · 2026-11-03 · No December discount
- **Decided by:** owner
- **Decision:** No site-wide discount in December. Gift guides instead.
- **Why:** margin target ≥ 55%; last year's 15% discount did not raise order count.
- **Applies until:** 2026-12-31
- **Status:** ACTIVE
- **Supersedes:** –

### D-003 · 2026-11-05 · Pause marketplace stock sync
- **Decided by:** operator (within AUTHORITY: technical)
- **Decision:** Paused the stock-sync job after it set 4 products to 0 stock by mistake; products restored from snapshot.
- **Why:** the sync used a supplier file that was 5 days old.
- **Applies until:** owner reviews the sync source
- **Status:** ACTIVE
- **Supersedes:** –
