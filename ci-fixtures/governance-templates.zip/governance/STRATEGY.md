# STRATEGY — the plan the daily loop executes

> **Instructions (delete when done).** The plan leads; daily runs execute it. The planner may only create tasks that serve a goal
> below, or that fix something broken. Write 2–4 goals, each with a metric, baseline, target and date (from BUSINESS-MODEL.md).
> For each goal: the bets (what you will try) and what you will *not* do. Review every 14 days, or earlier when a trigger fires —
> the operator drafts the review, you approve it. Keep the review log to 6 entries; older ones move to DECISIONS.md.
> Size budget: 900 words.

## Template

Owner: <your name> · Period: <start> – <end> · Next review: <YYYY-MM-DD>

### Goals
| # | Goal | Metric | Baseline | Target | By |
|---|---|---|---|---|---|

### Bets per goal
**G1 — <goal>**
- Bet: <what we try> · Evidence it may work: <source> · First check: <date>
- Not doing: <tempting work we skip, and why>

### Review triggers (start a review before the date if any fires)
- <trigger>

### Open questions for the owner
- <question>

### Review log (max 6)
| Date | What changed | Why |
|---|---|---|

## Example — Harbor & Pine Candles

Owner: Sam (fictional) · Period: 2026-11-01 – 2027-01-31 · Next review: 2026-11-15

### Goals
| # | Goal | Metric | Baseline | Target | By |
|---|---|---|---|---|---|
| G1 | More orders from search | Organic clicks to product pages / month | 3,400 | 4,250 | 2027-01-31 |
| G2 | Convert gift traffic in December | Own-shop orders / month | 140 | 190 | 2026-12-31 |
| G3 | Keep the shop healthy | Broken links + 404s with traffic | 14 | 0 | 2026-11-30 |

### Bets per goal
**G1 — More orders from search**
- Bet: rewrite meta descriptions and intros for the 30 product pages with most impressions and CTR < 2%. · Evidence: Search Console, Oct. · First check: 2026-11-29 (prediction: CTR +0.5 pt).
- Not doing: blog topics without search demand — no evidence they sell candles.

**G2 — Convert gift traffic**
- Bet: three gift guides (under €25, for cosy evenings, for new homes), each linking 8 products. Atlas drafts; the owner approves publishing (AUTHORITY). · First check: 2026-12-10.
- Not doing: discounts — an owner decision that hurts margin.

**G3 — Healthy shop**
- Bet: weekly broken-link scan; fix or redirect within 24 h.

### Review triggers (start a review before the date if any fires)
- Orders drop more than 20% week on week.
- A goal is clearly met or clearly out of reach.
- The owner logs a decision that changes a goal.

### Open questions for the owner
- Do we want a newsletter before December? (needs a tool → spend approval)

### Review log (max 6)
| Date | What changed | Why |
|---|---|---|
| 2026-11-01 | Strategy created | Start of Atlas |
