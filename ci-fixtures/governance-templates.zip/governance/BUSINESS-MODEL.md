# BUSINESS-MODEL — how this business actually makes money

> **Instructions (delete when done).** This file gives the planner the economics it needs to judge expected value — without it,
> a model optimises for activity. Write how money really comes in today, not the pitch deck. Give the numbers that matter for
> decisions (average order value, margin, main costs, channels) and mark each with its source and date. "Unknown" is allowed.
> Name what "good" looks like in numbers for the next period — STRATEGY.md builds on it. The operator may propose updates in the
> briefing; you apply them. Size budget: 700 words.

## Template

Owner: <your name> · Last reviewed: <YYYY-MM-DD>

### In one sentence
<who buys what, why, and through which channel>

### Revenue streams
| Stream | Share of revenue | Avg order value | Gross margin | Source & date |
|---|---|---|---|---|

### Costs that matter for decisions
| Cost | Amount | Fixed / variable | Source & date |
|---|---|---|---|

### Where customers come from
| Channel | Share of orders | Notes |
|---|---|---|

### What "good" means (next 90 days)
- <metric>: from <baseline> to <target> by <date>

### Constraints
- <time, stock, cash, skills, seasonality>

### Unknowns the operator should help answer
- <question>

## Example — Harbor & Pine Candles

Owner: Sam (fictional) · Last reviewed: 2026-11-02

### In one sentence
People in the UK and EU buy hand-poured soy candles and wax melts from our WooCommerce shop, mostly as gifts, found through search and Pinterest.

### Revenue streams
| Stream | Share of revenue | Avg order value | Gross margin | Source & date |
|---|---|---|---|---|
| Own shop (WooCommerce) | 80% | €34 | 58% | shop export, Oct 2026 |
| Marketplace listings | 20% | €24 | 36% (after fees) | marketplace report, Oct 2026 |

### Costs that matter for decisions
| Cost | Amount | Fixed / variable | Source & date |
|---|---|---|---|
| Wax, jars, wicks, fragrance | ~32% of price | variable | supplier invoices, Q3 2026 |
| Shipping subsidy (fragile glass) | €3.40 per order | variable | carrier invoices, Oct 2026 |
| Hosting + plugins | €38 / month | fixed | billing, Oct 2026 |

### Where customers come from
| Channel | Share of orders | Notes |
|---|---|---|
| Organic search | 44% | most land on product pages |
| Pinterest | 23% | strong for gift ideas, Nov–Dec peak |
| Direct / returning | 19% | no newsletter yet |
| Marketplace | 14% | lower margin |

### What "good" means (next 90 days)
- Own-shop orders: from 140 to 190 per month by 2027-01-31.
- Organic search clicks to product pages: +25% vs October baseline.
- Gross margin stays at or above 55%.

### Constraints
- Owner has 4 hours a week; candles cure 2 weeks before they can ship; December is ~30% of annual revenue.

### Unknowns the operator should help answer
- Which 10 products get most organic clicks but convert below 1%?
