# CURRENT — the decisions that apply right now

> **Instructions (delete when done).** The compact view of DECISIONS.md that the operator reads every run: DECISIONS is the
> archive, CURRENT is the rulebook. Only ACTIVE decisions, one line each, with the D-number so the reasoning can be found.
> Group by area; remove a line the day its decision is superseded or expires. The operator regenerates this file after every
> new decision; you check it in the weekly review. Size budget: 400 words — if it no longer fits, merge decisions.

## Template

Last regenerated: <YYYY-MM-DD> from DECISIONS.md up to D-<NNN>

### <Area>
- <decision in one line> (D-<NNN>, until <date | superseded>)

## Example — Harbor & Pine Candles

Last regenerated: 2026-11-05 from DECISIONS.md up to D-003

### Product content
- Atlas may rewrite titles, meta descriptions and intros, max 5 products/day, snapshot + live check. (D-001, until superseded)

### Prices & offers
- No site-wide discount in December; use gift guides. (D-002, until 2026-12-31)

### Integrations
- Marketplace stock sync is paused until the owner reviews its source file. (D-003, until owner review)
