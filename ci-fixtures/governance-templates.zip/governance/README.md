# Governance pack — templates (Section 4)

Your operator reads these files **before every run**. They are the difference between "an AI that does things" and
"an AI that does the right things, within limits you set". Keep each file short: the operator reads all of them every time.

| File | Answers | Lecture | Update when |
|---|---|---|---|
| PRINCIPLES.md | What must never happen, whatever the plan says? | L4.1 | rarely — only after an incident or a values change |
| BUSINESS-MODEL.md | How does this business actually make money, and what is "good"? | L4.2 | when prices, channels or margins change |
| STRATEGY.md | What are we trying to achieve in the next 2–6 weeks, and in what order? | L4.3 | every 14 days, or when a trigger fires |
| AUTHORITY.md | What may the operator do alone, what needs approval, what never? | L4.4 | when you widen or narrow trust |
| DECISIONS.md | Full archive of owner decisions (append-only) | L4.5 | every decision |
| CURRENT.md | Compact "what applies now" extract of DECISIONS.md | L4.5 | every decision that changes current behaviour |
| LESSONS.md | Rules learned from failures and successes | L4.5 | after every failure post-mortem |

## How to fill them
1. Copy this folder into the root of your operator repository as `governance/`.
2. Each template has an **Instructions** block (delete it when done) and a filled **Example** for the fictional
   demo shop *Harbor & Pine Candles* used throughout the course. Replace the example with your own business.
3. Or let Claude interview you (L4.6): `claude "Read governance/README.md and interview me, one question at a time, to fill each template. Write the files when I confirm."`

## Rules of thumb
- **Specific beats wise.** "Never change a product price" is followed; "be careful with pricing" is not.
- **Numbers beat adjectives.** "Max 3 product edits per day" beats "don't do too much".
- **One source of truth per question.** If two files answer the same question, they will eventually disagree.
- **Bounded size.** PRINCIPLES ≤ 1 page, CURRENT ≤ 1 page, LESSONS ≤ 40 active rules (archive the rest).
- Order of precedence when files conflict: PRINCIPLES > AUTHORITY > CURRENT > STRATEGY > anything else.

## Check your pack
Run `node governance/check-governance.mjs governance/` (Node 18+, no installs). It fails when an Instructions block or an
`<placeholder>` is left, a required heading or authority level is missing, a decision or lesson lacks a field, or a file
grows past its size budget (PRINCIPLES 600 words, AUTHORITY 700, BUSINESS-MODEL 700, STRATEGY 900, CURRENT 400, LESSONS 900 / 40 rules).
Course maintainers: `node check-governance.mjs . --templates` checks the templates themselves; `node --test` runs the checker's tests.
